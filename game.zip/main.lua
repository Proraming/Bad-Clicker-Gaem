require "UI"

function love.load()
    clickerpower = 1
    cps = 1
    timer = 0
    money = 0
    Cclock = 0
    isup = false
    basic_cost = 50
    swarm_cost = 10

    Shop = UIElements.Frame:new()
    Shop:SetActiveState(true)
    Shop:AddElement(UIElements.Label:new("Clicks: " .. money, {350, 25}, {0, 50}, {0, 0, 1}))
    Shop:AddElement(UIElements.Label:new("Mouse \n shop", {745, 10}, {0, 0}, {0.3, 1, 0.3}))
    Shop:AddElement(UIElements.Label:new("Cost:" .. basic_cost, {740, 195}, {0, 0}, {0.3, 1, 0.3}))
    Shop:AddElement(UIElements.Label:new("Cost:" .. swarm_cost, {740, 350}, {0, 0}, {0.3, 1, 0.3}))
    Shop:AddElement(UIElements.Label:new("CPS: " .. cps, {350, 50}, {0, 50}, {0, 0, 1}))
    ClickerPowerImage = UIElements.Image:new(love.graphics.newImage("clicker.png"), {690, 75}, {0.25, 0.25})
    Buyclickerpower = UIElements.Imagebutton:new(ClickerPowerImage)
    Shop:AddElement(Buyclickerpower)
    
    SwarmImage = UIElements.Image:new(love.graphics.newImage("swarm.png"), {665, 200}, {1/12.5, 1/12.5})
    BuySwarm = UIElements.Imagebutton:new(SwarmImage)
    Shop:AddElement(BuySwarm)
    
    CalcImage = UIElements.Image:new(love.graphics.newImage("Screen.png"), {170, 100}, {1,1})
    Calc = UIElements.Imagebutton:new(CalcImage)
    Shop:AddElement(Calc)

    font = love.graphics.newFont("Sigmar-Regular.ttf",28)
    love.graphics.setFont(font)
end

function love.update()
    Shop.ElementContents[1].Text = "Clicks: " .. money
    Shop.ElementContents[3].Text = "Cost:" .. basic_cost
    Shop.ElementContents[4].Text = "Cost:" .. swarm_cost
    Shop.ElementContents[5].Text = "CPS: " .. cps
    funges()
    --[[if Collision(700, 22, 100, 95) and love.mouse.isDown(1) and isup == false then
        buyitem("clickerpower")
        isup = true
    end
    if Collision(700, 150, 100, 95) and love.mouse.isDown(1) and isup == false then
        buyitem("cps")
        isup = true
    end]]--
end

function funges()
    timer = timer + 0.5
    if timer == 60 then
        money = money + cps
        timer = 0
    end

    Buyclickerpower:IsTriggered(function ()
        buyitem("clickerpower")
    end, {Pos2D = {0, 0}, Scale2D = {100, 95}})

    BuySwarm:IsTriggered(function ()
        buyitem("cps")
    end, {Pos2D = {0, 0}, Scale2D = {100, 95}})

    Calc:IsTriggered(function ()
        money = money + clickerpower
        print(money)
    end, {Pos2D = {0, 75}, Scale2D = {400,315}})

    if not love.mouse.isDown(1) then
        isup = false
    end
end

--[[function Collision(x, y, ScaleX, ScaleY)
    if love.mouse.getX() > x and love.mouse.getX() < x + ScaleX then
        if love.mouse.getY() > y and love.mouse.getY() < y + ScaleY then
            return true
        end
    end
    return false
end--]]

function buyitem(ItemType)
    print("Buying item")
    if ItemType == "clickerpower" then
        if money >= basic_cost then
            money = money - basic_cost
            clickerpower = clickerpower + 1
            basic_cost = basic_cost * 2 - 30
        else
            print("Not enough money")
        end
    end
    if ItemType == "cps" then
        if money >= swarm_cost then
            money = money - swarm_cost
            swarm_cost = cps * 3 + 9
            cps = cps + 1
        else
            print("Not enough money")
        end
    end
end

function love.draw()
    love.graphics.setColor(.3, 0.3, 0.3)
    love.graphics.rectangle("fill", 680, 0, 125, 800)
    love.graphics.setBackgroundColor(.8, 1, 1)
    
    Shop:Draw()
    
end